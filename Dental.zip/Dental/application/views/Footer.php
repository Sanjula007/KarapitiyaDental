
<!DOCTYPE html>
<html lang="en">
 <body>

        <!-- *** FOOTER ***
 _________________________________________________________ -->
        <div id="footer" >
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <h4>Pages</h4>

                        <ul>
                            <li><a href="<?php echo base_url('assest/'); ?>text.html">About us</a>
                            </li>
                            <li><a href="<?php echo base_url('assest/'); ?>text.html">Terms and conditions</a>
                            </li>
                            <li><a href="<?php echo base_url('assest/'); ?>faq.html">FAQ</a>
                            </li>
                            <li><a href="<?php echo base_url('assest/'); ?>contact.html">Contact us</a>
                            </li>
                        </ul>
                    </div>

                    <div class="col-md-3 col-sm-6">

                        <h4>User section</h4>

                        <ul>
                            <li><a href="<?php echo base_url('assest/'); ?>#" data-toggle="modal" data-target="#login-modal">Login</a>
                            </li>
                            <li><a href="<?php echo base_url('assest/'); ?>register.html">Regiter</a>
                            </li>
                        </ul>

                        <hr class="hidden-md hidden-lg hidden-sm">

                    </div>
                    <!-- /.col-md-3 -->








                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">© 2015 Your name goes here.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="<?php echo base_url('assest/'); ?>http://bootstrapious.com/e-commerce-templates">Bootstrapious</a> with support from <a href="<?php echo base_url('assest/'); ?>https://kakusei.cz">Kakusei</a> 
                        <!-- Not removing these links is part of the licence conditions of the template. Thanks for understanding :) -->
                    </p>
                </div>
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="<?php echo base_url('assest/'); ?>js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/jquery.cookie.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/waypoints.min.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/modernizr.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/bootstrap-hover-dropdown.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url('assest/'); ?>js/front.js"></script>


</body>

</html>